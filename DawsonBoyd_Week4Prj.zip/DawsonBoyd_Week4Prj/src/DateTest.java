/**Date Project
 * @author Dawson Boyd
 * @version Spring 2021
 * CSci2001
 */

public class DateTest {
    public static void main(String[] args) {
        Date date = new Date(7, 30, 2003);
        date.displayDate();
    }
}
