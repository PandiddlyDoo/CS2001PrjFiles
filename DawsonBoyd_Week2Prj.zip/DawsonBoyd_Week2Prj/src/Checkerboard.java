/**Checkerboard Project
 * @author Dawson Boyd
 * @version Spring 2021
 * CSci 2001
 */

public class Checkerboard {
    public static void main(String[] args) {

        //Loop to print the pattern.. nothing too fancy with this one
        for(int i =0; i<4; i++){
            System.out.println("* * * * * * * * ");
            System.out.println(" * * * * * * * *");
        }

    }
}
